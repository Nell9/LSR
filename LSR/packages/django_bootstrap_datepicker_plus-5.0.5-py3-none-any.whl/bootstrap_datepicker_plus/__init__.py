"""Datepicker widgets for Django."""

__version__ = "5.0.5"

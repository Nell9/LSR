class NavTabMixin:
    is_navtab = True

"""Flatpickr widgets for Django."""

__version__ = "2.0.3"
